function edit(file = null, ext = null) {
    let message;
    if (file) {
        message = ext + file;
    } else {
        message = "sPeAk" + document.querySelector(".text").value;
    }
    fetch('/.netlify/functions/edit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: message }),
    })
    .then(response => response.json())
    .then(data => {
        console.log('Message sent successfully:', data);
        if (data.status === 'success') {
            document.querySelector(".text").value = '';
        }
    })
    .catch(error => {
        console.log('Error occurred while sending the message:', error);
    });
}

function status() {
    fetch('/.netlify/functions/time')
        .then(response => response.json())
        .then(data => {
            fetch('/.netlify/functions/fetch')
                .then(res => res.json())
                .then(statusData => {
                    const prev = statusData.prevTime;
                    const end = data.endTime;
                    if (end - prev > 4 || (prev === 0 && end === 0)) {
                        document.querySelector(".status").textContent = "Offline";
                        document.querySelector(".status").style.color = "red";
                    } else {
                        document.querySelector(".status").textContent = "Online";
                        document.querySelector(".status").style.color = "green";
                    }
                });
        })
        .catch(error => console.log("Status fetch failed", error));
}

function readFile() {
    const fileInput = document.getElementById('fileInput');
    const file = fileInput.files[0];

    if (file) {
        const formData = new FormData();
        formData.append("file", file);
        fetch('/.netlify/functions/upload-file', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('fileName').textContent = `File uploaded successfully: ${file.name}`;
                edit(file.name, "pLaY");
            } else {
                console.log("File upload failed:", data.message);
            }
        })
        .catch(error => {
            console.log("Error uploading file:", error);
        });

        fileInput.value = "";
        document.getElementById('fileName').textContent = '';
    } else {
        console.log("No file selected.");
    }
}

document.getElementById('fileInput').addEventListener('change', function () {
    const file = this.files[0];
    if (file) {
        document.getElementById('fileName').textContent = `Selected File: ${file.name}`;
    } else {
        document.getElementById('fileName').textContent = '';
    }
});

function updateFile() {
    const fileInput = document.getElementById('fileInput');
    const file = fileInput.files[0];

    if (file) {
        const formData = new FormData();
        formData.append('file', file);
        fetch('/.netlify/functions/upload-file', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                console.log("File updated successfully");
                document.getElementById('fileName').textContent = `File updated: ${file.name}`;
            } else {
                console.log("File update failed:", data.message);
            }
        })
        .catch(error => {
            console.log("Error updating file:", error);
        });
    } else {
        console.log("No file selected.");
    }
}

function getFiles() {
    fetch('/files')
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            display(data.files);
        } else {
            console.log('Error fetching files:', data.message);
        }
    })
    .catch(error => {
        console.error('Error fetching files:', error);
    });
}

function display(files) {
    const audioList = document.getElementById('audio-list');
    audioList.innerHTML = ''; 

    files.forEach(file => {
        const audioItem = document.createElement('div');
        audioItem.classList.add('audio-item');

        const trackName = document.createElement('span');
        trackName.textContent = file;  

        const playButton = document.createElement('button');
        playButton.classList.add('play-btn');
        playButton.textContent = '▶';

        audioItem.appendChild(trackName);
        audioItem.appendChild(playButton);
        audioList.appendChild(audioItem);
    });
}

function upload() {
    const fileInput = document.getElementById('file-input');
    const file = fileInput.files[0];

    if (file) {
        const formData = new FormData();
        formData.append('file', file); 
        fetch('/.netlify/functions/upload-file', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                console.log("Audio file uploaded successfully");
                fileInput.value = '';  
            } else {
                console.log("Audio file upload failed:", data.message);
            }
        })
        .catch(error => console.error("Error uploading audio file:", error));
    } else {
        console.log("No audio file selected.");
    }
}
getFiles()
import fs from 'fs';
import path from 'path';
import multer from 'multer';
import express from 'express';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const isNetlify = process.env.NETLIFY === 'true';  

const soundsDir = isNetlify ? '/tmp/sounds' : path.join(__dirname, '..', 'sounds');

// Ensure the sounds directory exists
if (!fs.existsSync(soundsDir)) {
    fs.mkdirSync(soundsDir, { recursive: true });
}

// Set up multer for file uploads
const upload = multer({ dest: soundsDir });

const messageFilePath = path.join(__dirname, '../../message.txt');
const startFilePath = path.join(__dirname, '../../start.json');
const endFilePath = path.join(__dirname, '../../end.json');

app.use(express.json());

app.post('/upload', upload.single('file'), (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ status: 'error', message: 'No file uploaded' });
        }

        const originalFileName = req.file.originalname;
        const savedFilePath = path.join(soundsDir, originalFileName);

        fs.renameSync(req.file.path, savedFilePath);

        return res.status(200).json({
            status: 'success',
            message: `File uploaded successfully: ${originalFileName}`,
        });
    } catch (err) {
        return res.status(500).json({ status: 'error', message: err.message });
    }
});

app.post('/edit', (req, res) => {
    try {
        const { text } = req.body;

        if (!text) {
            return res.status(400).json({ status: 'error', message: 'No text provided' });
        }

        fs.writeFileSync(messageFilePath, text, 'utf8');

        return res.status(200).json({ status: 'success', message: 'Message updated' });
    } catch (err) {
        return res.status(500).json({ status: 'error', message: err.message });
    }
});

app.get('/fetch', (req, res) => {
    try {
        const data = fs.readFileSync(messageFilePath, 'utf8');

        fs.writeFileSync(messageFilePath, '', 'utf8');

        const startData = { prevTime: Math.floor(Date.now() / 1000) };
        fs.writeFileSync(startFilePath, JSON.stringify(startData, null, 2), 'utf8');

        return res.status(200).json({ status: 'success', data });
    } catch (err) {
        return res.status(500).json({ status: 'error', message: err.message });
    }
});

app.get('/time', (req, res) => {
    try {
        const endData = { endTime: Math.floor(Date.now() / 1000) };
        fs.writeFileSync(endFilePath, JSON.stringify(endData, null, 2), 'utf8');

        return res.status(200).json({
            status: 'success',
            message: 'endTime updated successfully',
        });
    } catch (err) {
        return res.status(500).json({ status: 'error', message: err.message });
    }
});

app.get('/files', (req, res) => {
    try {
        fs.readdir(soundsDir, (err, files) => {
            if (err) {
                return res.status(500).json({ status: 'error', message: 'Failed to read directory' });
            }

            const fileNames = files.filter(file => fs.lstatSync(path.join(soundsDir, file)).isFile());

            return res.status(200).json({ status: 'success', files: fileNames });
        });
    } catch (err) {
        return res.status(500).json({ status: 'error', message: err.message });
    }
});

app.use((req, res) => {
    res.status(404).json({ status: 'error', message: 'Invalid endpoint or method' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
